# PixelNotes PWA - Project Context

## Overview
PixelNotes PWA (also referred to as Pixel Keep) is a secure, offline-first Progressive Web App designed for managing notes and quests (to-do lists) with a retro pixel art aesthetic. The application emphasizes privacy by encrypting all data locally using `crypto-js` before storing it in IndexedDB.

## Tech Stack
*   **Frontend:** Vanilla HTML5, JavaScript (ES6+)
*   **Styling:** Tailwind CSS (loaded via CDN) with a custom configuration for pixel art themes (fonts, box-shadows, colors).
*   **Fonts:** Google Fonts ("Press Start 2P", "Material Symbols Outlined", and others).
*   **Storage:** IndexedDB (via `idb` library).
*   **Encryption:** AES encryption using `crypto-js`.
*   **PWA Features:** Service Worker (`sw.js`) for offline caching and `manifest.webmanifest` for installation.
*   **Markdown Conversion:** `turndown.js` for converting HTML content to Markdown.

## Project Structure
*   `index.html`: The main entry point. Contains the application structure, inline styles, and the core application logic (JavaScript) typically found at the bottom of the file.
*   `sw.js`: The Service Worker script responsibly for caching assets and enabling offline functionality.
*   `manifest.webmanifest`: Configuration for the PWA (icons, theme colors, display mode).
*   `crypto-js.min.js`: Minified library for cryptographic operations.
*   `turndown.js`: Library for HTML to Markdown conversion.
*   `icons/`: Directory containing application icons for PWA installation.

## Development

### Building and Running
This project uses a "no-build" architecture. It runs directly in the browser.

**To run locally:**

1.  **Python (SimpleHTTPServer):**
    ```bash
    python -m http.server
    ```
    Access at `http://localhost:8000`

2.  **Node.js (http-server):**
    ```bash
    npm install -g http-server
    http-server .
    ```
    Access at `http://localhost:8080`

### Deployment
The project is configured for deployment on Firebase Hosting.
*   `firebase deploy` to deploy changes.

## Key Conventions
*   **Offline-First:** All critical assets must be cached in `sw.js`.
*   **Security:** Data is encrypted *before* storage. The encryption key is derived from the user's password (which is not stored).
*   **Styling:** Use Tailwind utility classes. Custom pixel-art specific classes (like `.shadow-pixel-container`) are defined in the Tailwind config within `index.html`.
*   **Single Page:** The application functions as a Single Page Application (SPA) by toggling visibility of sections (e.g., `.page` classes), though it is implemented in a single HTML file.
